#include<stdio.h>
void main() {
    char s[30];
    printf("Enter a sentence : ");
    scanf("%[^\n]s",s);
    printf("You entered : %s\n",s);
}
