#include<stdio.h>
#include<string.h>
void main() {
    char s1[10],s2[10];
    printf("Enter a string in lower case : ");
    gets(s1);
    strupr(s1);
    printf("String in upper case : ");
    puts(s1);
    printf("Enter a string in upper case : ");
    gets(s2);
    strlwr(s2);
    printf("String in lower case : ");
    puts(s2);
}
