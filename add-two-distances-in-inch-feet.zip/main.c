#include <stdio.h>

int main() {
    struct distance {
        int inch;
        int feet;
    }a,b,sum;
    printf("Enter first feet : ");
    scanf("%d",&a.feet);
    printf("Enter first inch : ");
    scanf("%d",&a.inch);
    printf("Enter second feet : ");
    scanf("%d",&b.feet);
    printf("Enter second inch : ");
    scanf("%d",&b.inch);
    sum.feet=a.feet + b.feet;
    sum.inch=a.inch + b.inch;
    if(sum.inch>12) {
        sum.inch-=12;
        ++sum.feet;
    }
    printf("\n\nSum is %d feet and %d inch",sum.feet,sum.inch);
    return 0;
}

