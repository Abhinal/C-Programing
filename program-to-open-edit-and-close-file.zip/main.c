#include <stdio.h>

int main() {
    long long int a;
    FILE *fptr;
    fptr = fopen("mob_num.txt","a");
    printf("Enter your mobile number\n");
    scanf("%lld",&a);
    fprintf(fptr,"%lld\n",a);
    fclose(fptr);
    printf("Your mobile number stored in database");

    return 0;
}
