#include<stdio.h>
#include<stdlib.h>
void main()
{
    char *charptr;
    charptr=(char*)malloc(20*sizeof(char));
    printf("Enter text : ");
    scanf("%s",charptr);
    printf("Output : ");
        printf("%s",charptr);

}
