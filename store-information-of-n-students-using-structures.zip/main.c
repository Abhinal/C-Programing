#include <stdio.h>

int main() {
        int n;
    printf("Enter number of Students : ");
    scanf("%d",&n);

    struct student {
        char fname[15];
        char lname[15];
        int classroll;
        char univroll[15];
    }st[n];
    for(int i=0;i<n;i++) {
    printf("Enter Student's First Name : ");
    scanf("%s",st[i].fname);
    printf("Enter Student's Last Name : ");
    scanf("%s",st[i].lname);
    printf("Enter Student's Class Roll : ");
    scanf("%d",&st[i].classroll);
    printf("Enter Student's Univ Roll : ");
    scanf("%s",st[i].univroll);
    }
    for(int i=0;i<n;i++) {
    printf("\n\nStudent's name : %s %s\nClass Roll no. : %d\nUniversity Roll no. : %s",st[i].fname,st[i].lname,st[i].classroll,st[i].univroll);
    }
    return 0;
}



