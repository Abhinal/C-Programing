#include <stdio.h>
void Swap(int *x, int *y) {
    int Temp;
    Temp = *x;
    *x = *y;
    *y = Temp;
}
void quick_Sort(int a[], int first, int last) {
    int pivot, i, j;
    if(first < last)
	{
        pivot = first;
        i = first;
        j = last;
        while (i < j) 
		{
            while(a[i] <= a[pivot] && i < last)
                i++;
            while(a[j] > a[pivot])
                j--;
            if(i < j) {
                Swap(&a[i], &a[j]);
            }
        }
        Swap(&a[pivot], &a[j]);
        quick_Sort(a, first, j - 1);
        quick_Sort(a, j + 1, last);
    }
}
int main() 
{
    int a[100], n, i;
    printf("Enter limit  :  ");
    scanf("%d", &n);
    for(i = 0; i < n; i++) {
        printf("Enter the Array Elements : ");\
        scanf("%d", &a[i]);
    }
    quick_Sort(a, 0, n - 1);
    printf("Quick Sort Result : ");
    for(i = 0; i < n; i++)  
	{
        printf(" %d", a[i]);
    }
    return 0;
}
