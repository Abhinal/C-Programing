#include<stdio.h>
int sum(int n);
int avg(float,float);
void main() {
    int n,sum1;
    printf("Enter limit ");
    scanf("%d",&n);
    sum1 = sum(n);
    float avg1 = avg(sum1,n);
    printf("Sum is %d and Average is %f",sum1,avg1);
}
int sum(int n) {
    int a[100],sum=0;
    for(int i=0;i<n;i++) {
        printf("Enter number ");
        scanf("%d",&a[i]);
        sum += a[i];
    }
    return sum;
}
int avg(float sum,float limit) {
    return sum/limit;
}