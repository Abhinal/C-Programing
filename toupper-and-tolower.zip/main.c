#include <stdio.h>
void upper(int c) {
    printf("%c",c-32);
}
void lower(int c) {
    printf("%c",c+32);
}
int main() {
    char ch;
    printf("Enter a character ");
    scanf("%c",&ch);
    int c = ch;
    if(c>64 && c<91){
       lower(c);}
    else upper(c);
    return 0;
}
