#include<stdio.h>
#include<string.h>
void main() {
    char s[30];
    int i,v=0,c=0;
    printf("Enter a sentance \n");
    gets(s);
    for(i=0;i<strlen(s);i++)
    {
        if(s[i]=='a'||s[i]=='e'||s[i]=='i'||s[i]=='o'||s[i]=='u'||s[i]=='A'||s[i]=='E'||s[i]=='I'||s[i]=='O'||s[i]=='U')
            v++;
        else if((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z'))
            c++;
    }
    printf("Number of vowels: %d\n",v);
    printf("Number of consonants: %d\n",c);

}
