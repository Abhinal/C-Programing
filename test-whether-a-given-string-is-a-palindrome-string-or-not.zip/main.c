#include<stdio.h>
#include<string.h>
void main() {
    char s1[40],s2[80];
    int k;
    printf("Enter a string : ");
    gets(s1);
    strcpy(s2,s1);
    strrev(s1);
    k=strcmp(s1,s2);
    if(k==0)
        printf("Palindrome String");
    else printf("Not a Palindrome String");
}
