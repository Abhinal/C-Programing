#include <stdio.h>
#include<stdlib.h>
int main() {
    struct student {
        char fname[15];
        char lname[15];
        int classroll;
        long long int univroll;
    }st;
    printf("Enter Student's First Name : ");
    scanf("%s",st.fname);
    printf("Enter Student's Last Name : ");
    scanf("%s",st.lname);
    printf("Enter Student's Class Roll : ");
    scanf("%d",&st.classroll);
    printf("Enter Student's Univ Roll : ");
    scanf("%lld",&st.univroll);
    printf("\n\nStudent's name : %s %s\nClass Roll no. : %d\nUniversity Roll no. : %lld",st.fname,st.lname,st.classroll,st.univroll);
    return 0;
}






