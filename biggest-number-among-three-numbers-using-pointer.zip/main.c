#include <stdio.h>

void main()
{
    int num1,num2,num3,*p1=&num1,*p2=&num2,*p3=&num3;
    printf("Enter three numbers :\n");
    scanf("%d%d%d",p1,p2,p3);
    if(*p1>*p2 && *p1>*p3)
        printf("Biggest number is %d",*p1);
    else if(*p2>*p1 && *p2>*p3)
        printf("Biggest number is %d",*p2);
    else printf("Biggest number is %d",*p3);
}
