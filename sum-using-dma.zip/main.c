#include <stdio.h>
#include <stdlib.h>
int main() {
    int n,*ptr,sum=0;
    printf("Enter size : ");
    scanf("%d",&n);
    ptr=(int*)malloc(n*sizeof(int));
    for(int i =0; i<n; i++) {
        printf("Enter number : ");
        scanf("%d",ptr+i);
        sum= sum + *(ptr+i);
    }
    printf("Sum is %d : ",sum);
    return 0;
}
