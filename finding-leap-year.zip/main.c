#include <stdio.h>
int check_ly(int year) {
    if((year%400==0) || (year%4==0 && year%100!=0))
    {return 1;}
    return 0;
}
void main()
{
    int year;
    printf("Enter a year ");
    scanf("%d",&year);
    check_ly(year);
}
