#include <stdio.h>

void main()
{
    int num1,num2,*first=&num1,*second=&num2;
    printf("Enter value of first number : ");
    scanf("%d",first);
    printf("Enter value of second number : ");
    scanf("%d",second);
        *first = *first ^ *second;
        *second = *first ^ *second;
        *first = *first ^ *second;
    printf("Your first no. is : %d\n",*first);
    printf("Your second no. is : %d",*second);
}
