#include <stdio.h>
int check(int* , int, int);
int main()  {
    int size,a[10],key;
    printf("Enter array size ");
    scanf("%d",&size);
    printf("Enter number in ascending order.\n");
    for(int i=0;i<size;i++) {
        printf("Enter Number ");
        scanf("%d",&a[i]);
    }
    printf("Enter search key");
    scanf("%d",&key);
    int flag = check(a,size,key);
    if (flag!=0)
    printf("\nFound in position %d",flag);
    else printf("Not Found");
    return 0;
}
int check(int a[],int s,int k) {
    int l=0,h=s-1,mid;
    while(l<=h) {
        mid =(l+h)/2;
        if (k==a[mid])
        return mid+1;
        else if(k>a[mid])
        l=mid+1;
        else h=mid-1;
    }
    return 0;
}
