#include <stdio.h>
#include<math.h>
int det(int a, int b, int c) {
    return ((b*b)-(4*a*c));
}
void root(int d, int b, int a) {
    int R1 = (-b+d)/(2*a);
    int R2 = (-b-d)/(2*a);
    printf("Roots are %d and %d",R1,R2);
}
int main() {
    int a,b,c,d;
printf("Enter value of a ");
scanf("%d",&a);
printf("Enter value of b ");
scanf("%d",&b);
printf("Enter value of c ");
scanf("%d",&c);
d = det(a,b,c);
    if (d>=0) {
        d = pow(d,0.5);
        root(d,b,a); }
    else printf("NO REAL ROOTS");
}

