#include <stdio.h>
void line(int s) {
    for(int i=0;i<s;i++) {
        printf("_");
    }
}
void main()
{
    int s;
    printf("Enter size of the line ");
    scanf("%d",&s);
    line(s);
}
