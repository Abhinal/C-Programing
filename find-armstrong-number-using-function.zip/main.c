#include <stdio.h>
#include<math.h>
int check_armstrong(int,int);
int check_digit(int);
void main() {
    int n,flag,a;
    printf("\nEnter number");
    scanf("%d",&a);
    n = check_digit(a);
    flag = check_armstrong(a,n);
    if( flag ==a) 
        printf("Armstrong Number");
    else printf("not an Armstrong Number");
}

int check_digit(int a) {
    int n=0;
    for(;a!=0;n++){
        a=a/10;
    }
    return n;
}

int check_armstrong(int a,int n) {
    int flag=0,i,b;
    for(i=0,b=a;i<n;i++,a=a/10) {
        b=a%10;
        flag=flag+pow(b,n);
    }
    return flag;
}
