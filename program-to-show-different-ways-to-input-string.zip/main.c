#include<stdio.h>
void main() {
    char s1[20],s2[20];
    printf("Enter a string : ");
    scanf("%[^\n]s",s2);    /*to store space-separated strings*/
    printf("You entered : %s\n",s2);
    printf("Enter a string : ");
    scanf("%s",s1); /*to store strings without space between them*/
    printf("You entered : %s\n",s1);
}
