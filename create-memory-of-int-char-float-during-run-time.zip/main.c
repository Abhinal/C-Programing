#include <stdio.h>
#include <stdlib.h>
int main() {
    int a,b,c,*intptr;
    char *charptr;
    float *floatptr;
    printf("Enter limit of integer : ");
    scanf("%d",&a);
    printf("Enter limit of character : ");
    scanf("%d",&b);
    printf("Enter limit of float : ");
    scanf("%d",&c);
    intptr=(int*)calloc(a,sizeof(int));
    charptr=(char*)malloc(b*sizeof(char));
    floatptr=(float*)calloc(c,sizeof(float));
    printf("Enter all numbers : \n");
    for(int i=0;i<a;i++) {
        scanf("%d",intptr+i);
    }
    printf("Enter all characters : \n");
    for(int i=0;i<b;i++) {
        scanf(" %c",charptr+i);
    }
    printf("Enter all float value : \n");
    for(int i=0;i<c;i++) {
        scanf("%f",floatptr+i);
    }
    printf("Input numbers : \n");
    for(int i=0;i<a;i++) {
        printf("%d\n",*(intptr+i));
    }
    printf("Input characters : \n");
    for(int i=0;i<b;i++) {
        printf("%c\n",*(charptr+i));
    }
    printf("Input float value : \n");
    for(int i=0;i<c;i++) {
        printf("%f\n",*(floatptr+i));
    }
    return 0;
}
