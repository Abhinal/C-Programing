#include <stdio.h>
#include <stdlib.h>
void main() {
    int *ptr,n,i,ans;
    printf("Enter limit : ");
    scanf("%d",&n);
    ptr = (int*)calloc(n,sizeof(int));
    for(i=0;i<n;i++) {
        printf("Enter number : ");
        scanf("%d",ptr+i);
    }
    for(ans=*(ptr+0),i=0;i<n;i++) {
        if(ans<*(ptr+i))
            ans=*(ptr+i);
    }
    printf("Largest no. is : %d",ans);
}
