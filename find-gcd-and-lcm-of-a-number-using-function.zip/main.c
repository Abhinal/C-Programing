#include <stdio.h>
int find_gcd(int , int);
int find_lcm(int,int,int);
int main()
{
    int a,b;
    printf("Enter two Numbers\n");
    scanf("%d%d",&a,&b);
    int gcd = find_gcd(a,b);
    int lcm = find_lcm(gcd,a,b);
    printf("GCD is %d and LCM is %d",gcd,lcm);
}

int find_gcd(int c,int d) {
    int gcd;
   for(int i=1;i<=c && i<=d;i++) {
       if(c%i==0 && d%i==0) {
           gcd = i;
       }
   }
    return gcd;
}
int find_lcm(int e,int f,int g) {
    return (f*g)/e;
}
