#include<stdio.h>
#include<string.h>
void main() {
    char s1[10],s2[10];
    int n;
    puts("Enter two strings");
    gets(s1);
    gets(s2);
    n=strcmp(s1,s2);
    if(n==0)
        printf("Identical strings\n");
    else
        printf("Strings are not identical\n");
     strcat(s1,s2);
     printf("Concatenated strings: %s\n",s1);
}
