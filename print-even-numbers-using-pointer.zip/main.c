#include <stdio.h>

void main()
{   int num1,num2,*m=&num1,*n=&num2;
    printf("Enter first numer : ");
    scanf("%d",m);
    printf("Enter second number : ");
    scanf("%d",n);
    for(*m=*m+*m%2;*m<=*n;*m+=2) {
        printf("%d ",*m);
    }
}
