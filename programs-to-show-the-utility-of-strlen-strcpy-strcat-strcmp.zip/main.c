#include<stdio.h>
#include<string.h>
void main() {
   char s1[20] = "Hello", s2[20], s3[] = "World";
   int lenofs3 = strlen(s3);
   strcpy(s2,s1);
   strcat(s1,s3);
   int compare = strcmp(s2,"Hello");
   printf("strlen(): Length of '%s' is %d\n",s3,lenofs3);
   printf("strcpy(): After copying s2 = %s\n",s2);
   printf("strcat(): After appending s1 = %s\n",s1);
   if(compare == 0)
    printf("strcmp(): The two strings are identical");
}