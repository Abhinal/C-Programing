#include<stdio.h>
#include<stdlib.h>
void main() {
    char *s=calloc(20,sizeof(char));
    printf("Enter a string : ");
    scanf("%[^\n]s",s);
    printf("You entered : %s",s);
}
