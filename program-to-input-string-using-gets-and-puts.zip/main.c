#include<stdio.h>
void main() {
    char s[20];
    puts("Enter a sentance");
    gets(s);
    puts("You entered : ");puts(s);
}
