num1=input("Enter first number : ");
num2=input("Enter second number :");
sum = int(num1) + int(num2) ;
print(sum);