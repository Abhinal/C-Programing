#include <stdio.h> 
int main() 
{ 
int *i, *j; 

if(i == j)
    printf("This might get printed if both i and j are same by chance.\n"); 
else printf("This is printed because i and j are not same before intialising NULL.\n");
 i = NULL;
 j = NULL; 
if(i == j) 
{ 
printf("This is always printed because i and j are same."); 
} 
return 0; 
} 
