#include <stdio.h>
void main() {
    int a[100], n, i, j, temp;
    printf("Enter limit : ");
    scanf("%d", &n);
    for(i = 0; i < n; i++) {
            printf("Enter the Array Elements : ");
        scanf("%d", &a[i]);
    }
    for(i = 1; i < n; i++) {
        for(j = i; j > 0 && a[j - 1] > a[j]; j--) {
                temp = a[j];
                a[j] = a[j - 1];
                a[j - 1] = temp;
        }
    }
    printf("Insertion Sort Result : ");
    for(i = 0; i < n; i++)
    {
        printf(" %d", a[i]);
    }
}

