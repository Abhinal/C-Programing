#include<stdio.h>
int check_prime(int c);
void main() {
    int i,a,b,flag;
    printf("Enter two numbers\n");
    scanf("%d%d",&a,&b);
        for(i=a;i<=b;i++)
        {
            flag = check_prime(i);
            if(flag == 1)
            printf("\n%d",i);
        }
    }   
int check_prime(int c) {
    int j,d=1;
    for(j=2;j<c;j++) {
        if(c%j==0) {
            d=0;
            break;
        }
    }
    return d;
}
