#include <stdio.h>

int main() {
    printf("-----For existing file-------\n");
    FILE *fptr = fopen("textfile.txt","r");
    if(fptr==NULL)
        printf("Error !! No file found.\n");
    else printf("File opened successfully.\n");
    
    printf("\n-----For non existing file-------\n");
    
    
    FILE *fptr1 = fopen("textfile1.txt","r");
    if(fptr1==NULL)
        printf("Error !! No file found.\n");
    else printf("File opened successfully.\n");
    return 0;
}
