#include <stdio.h>

int main() {
    char ch[15];
    FILE *fptr;
    fptr = fopen("file.txt","r");
    fscanf(fptr,"%s",ch);
    printf("%s",ch);
    fclose(fptr);
    return 0;
}
