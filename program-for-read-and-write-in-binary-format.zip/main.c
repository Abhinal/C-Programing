#include <stdio.h>

int main() {
    int num,num1;
    FILE *fptr;
    fptr = fopen("file.bin","w+");
    printf("Enter number : ");
    scanf("%d",&num);
    fwrite(&num,sizeof(num),1,fptr);
    fclose(fptr);
    
    fopen("file.bin","rb");
    fread(&num1,sizeof(num1),1,fptr);
    printf("Number stored in binary format is %d",num1);
    fclose(fptr);

    return 0;
}
