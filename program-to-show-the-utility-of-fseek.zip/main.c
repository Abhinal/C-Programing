#include <stdio.h>

int main() {
    FILE *fptr;
    fptr = fopen("file.txt","r");
    printf("Seeking the end of the file.\n");
    fseek(fptr,0,SEEK_END);
    printf("Position: %ld\n",ftell(fptr));
    printf("Seeking the 4th byte before the end of the file.\n");
    fseek(fptr,-4,SEEK_END);
    printf("Position: %ld\n",ftell(fptr));
   return 0;
}