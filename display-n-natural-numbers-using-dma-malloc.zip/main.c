#include <stdio.h>
#include <stdlib.h>
void main() {
    int n,*ptr;
    printf("Enter limit : ");
    scanf("%d",&n);
    ptr=(int*)malloc(n*sizeof(int));
    for(int i=0;i<n;i++) {
        printf("Enter no. : ");
        scanf("%d",ptr+i);
    }
    for(int i=0;i<n;i++) {
        printf("%d. %d\n",i+1,*(ptr+i));
    }
}
