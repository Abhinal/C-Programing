#include <stdio.h>
int f(int a) {
    int y=1;
    for(int i=1;i<=a;i++) {
        y = y*i;
    }
    return y;
}
int p(int a, int b) {
    int n = f(a);
    int d = f(a-b);
    return n/d;
}
int c(int a, int b) {
    int n = f(a);
    int d = f(a-b);
    int D = f(b);
    return n/(d*D);
}
int main()
{
    int n,r;
    printf("Enter the number ");
    scanf("%d",&n);
    printf("Enter the value of r ");
    scanf("%d",&r);
    int factorial = f(n);
    int permutation = p(n,r);
    int combination = c(n,r);
    printf("Factorial is %d, Permutation is %d and Combination is %d",factorial,permutation,combination);
    return 0;
}
