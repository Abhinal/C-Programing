#include <stdio.h>

typedef struct complex {
    float real;
    float imaginary;
}complex;
complex add(complex a,complex b);
int main() {
    complex a,b,sum;
    printf("Enter real and imaginary part of first number :\n");
    scanf("%f%f",&a.real,&a.imaginary);
    printf("Enter real and imaginary part of second number :\n");
    scanf("%f%f",&b.real,&b.imaginary);
    
    sum=add(a,b);
printf("Sum is %.3f + %.3fi",sum.real,sum.imaginary);
    return 0;
}
complex add(complex a,complex b) {
    complex temp;
    temp.real=a.real+b.real;
    temp.imaginary=a.imaginary+b.imaginary;
    return(temp);
}
