#include <stdio.h>

int main() {
    struct student {
        char fname[15];
        char lname[15];
        int classroll;
        char univroll[15];
    }st[10];
    for(int i=0;i<10;i++) {
    printf("Enter Student First Name : ");
    scanf("%s",st[i].fname);
    printf("Enter Student Last Name : ");
    scanf("%s",st[i].lname);
    printf("Enter Student Class Roll : ");
    scanf("%d",&st[i].classroll);
    printf("Enter Student Univ Roll : ");
    scanf("%s",st[i].univroll);
    }
    for(int i=0;i<10;i++) {
    printf("\n\nStudent's name : %s %s\nClass Roll no. : %d\nUniversity Roll no. : %s",st[i].fname,st[i].lname,st[i].classroll,st[i].univroll);
    }
    return 0;
}



