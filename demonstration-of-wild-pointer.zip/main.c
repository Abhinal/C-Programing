#include <string.h>
#include<stdio.h>
int main(){
void *ptr;
printf("%p",ptr);

return 0;
}