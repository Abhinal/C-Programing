#include <stdio.h>

void main()
{
    int num1,num2,sum,*p1= &num1,*p2= &num2;
    printf("Enter first number : ");
    scanf("%d",p1);
    printf("Enter second number : ");
    scanf("%d",p2);
    sum = *p1 + *p2;
    printf("Sum is %d",sum);
}
