#include<stdlib.h> 
#include<stdio.h>  
int main() 
{ 
    int x = 4; 
    float y = 5.5; 
    char z ='A';
    void *ptr;
    
    ptr = &x; 
    printf("Integer variable is = %d", *( (int*) ptr) ); 
    
    ptr = &y;  
    printf("\nFloat variable is = %.2f", *( (float*) ptr) ); 
    
    ptr = &z;
    printf("\nCharacter variable is = %c",*( (char*) ptr) );
    
    return 0; 
} 