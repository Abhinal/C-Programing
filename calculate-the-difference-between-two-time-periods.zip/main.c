#include <stdio.h>
struct caltime {
   int seconds;
   int minutes;
   int hours;
}start,stop,diff;

int main() {
   printf("Enter the start time. \nEnter hours, minutes and seconds : ");
   scanf("%d %d %d", &start.hours, &start.minutes, &start.seconds);
   printf("Enter the stop time. \nEnter hours, minutes and seconds : ");
   scanf("%d %d %d", &stop.hours, &stop.minutes, &stop.seconds);
   diff.hours=stop.hours-start.hours;
   diff.minutes=stop.minutes-start.minutes;
   if(diff.minutes<0) {
       diff.minutes+=60;
       diff.hours-=1;
   }
   diff.seconds=stop.seconds-start.seconds;
      if(diff.seconds<0) {
       diff.seconds+=60;
       diff.minutes-=1;
   }
   printf("The difference of time period is %d:%d:%d",diff.hours,diff.minutes,diff.seconds);
}
