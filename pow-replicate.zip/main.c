#include <stdio.h>
void cal(int x,int n) {
    int i,y=1;
    for(i=0;i<n;i++) {
        y *=x;
    }
    printf("%d",y);
}

void main()
{
    int b,power;
    printf("Enter Base ");
    scanf("%d",&b);
    printf("Enter Power ");
    scanf("%d",&power);
    cal(b,power);
}
