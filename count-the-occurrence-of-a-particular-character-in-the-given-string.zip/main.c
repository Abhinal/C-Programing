#include<stdio.h>
#include<string.h>
void main() {
    char s[20],c;
    int count=0,i,l;
    printf("Enter a string : ");
    gets(s);
    printf("Enter a character to be searched : ");
    scanf("%c",&c);
    l=strlen(s);

    for( i=0;i<l;i++) {
        if(s[i]==c)
        count++;
    }
    printf("%c occered %d times",c,count);
}
